import "./footer.css";

function Footer(): JSX.Element {
    return (
        <div className="footer">
			by Gilad Yitzhak
        </div>
    );
}

export default Footer;
