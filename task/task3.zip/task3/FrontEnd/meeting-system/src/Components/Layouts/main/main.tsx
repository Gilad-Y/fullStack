import "./main.css";

function Main(): JSX.Element {
    return (
        <div className="main">
			main
        </div>
    );
}

export default Main;
