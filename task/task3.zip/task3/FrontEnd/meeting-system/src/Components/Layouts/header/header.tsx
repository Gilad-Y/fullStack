import "./header.css";

function Header(): JSX.Element {
    return (
        <div className="header">
			meeting-system
        </div>
    );
}

export default Header;
