import "./page404.css";

function Page404(): JSX.Element {
    return (
        <div className="page404">
			page 404
        </div>
    );
}

export default Page404;
