export class devTeam {
  public teamCode: number;
  public teamName:string

  constructor(teamCode:number,teamName:string) {
    this.teamCode=teamCode,
    this.teamName=teamName
  }
}
